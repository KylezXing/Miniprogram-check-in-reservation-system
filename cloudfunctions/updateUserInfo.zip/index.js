const cloud = require('wx-server-sdk');
cloud.init();
const db = cloud.database();
console.log("3333333333");
exports.main = async (event, context) => {
    console.log("3333333333");
  try {
    console.log("333333333333333333333333");
    const { OPENID } = cloud.getWXContext();
    const { name, phone } = event;
    console.log("event:",event);
    console.log("11111:",name,"2222",phone);
    return await db.collection('userinfo').update({
      data: {
        name: name,
        phone: phone
      },
      filter:{
          where:{
              openid=OPENID
          }
      }
    });
  } catch (err) {
    console.error(err);
  }
};